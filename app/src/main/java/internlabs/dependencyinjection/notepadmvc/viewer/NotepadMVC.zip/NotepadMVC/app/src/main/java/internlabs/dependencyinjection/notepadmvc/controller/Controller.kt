package internlabs.dependencyinjection.notepadmvc.controller

class Controller {
}